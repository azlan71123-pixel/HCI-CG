"""
LAB 1 - Task 4: Spatial Downsampling & Pixelation via Striding
HCI & Computer Graphics
"""

import numpy as np
import matplotlib.pyplot as plt
from PIL import Image


def main():
    N = 8

    # Load original image
    original = np.array(Image.open("sample.jpg").convert("RGB"))

    # 1. Downsample using NumPy striding
    downsampled = original[::N, ::N, :]

    # 2. Re-expand back to original dimensions using np.repeat on axes 0 and 1
    re_expanded = np.repeat(downsampled, N, axis=0)
    re_expanded = np.repeat(re_expanded, N, axis=1)

    # Trim/pad in case of rounding mismatch with the original shape
    re_expanded = re_expanded[: original.shape[0], : original.shape[1], :]

    # 3. Percentage drop in spatial dimensions and memory footprint
    dim_reduction_pct = (1 - (downsampled.shape[0] / original.shape[0])) * 100
    memory_reduction_pct = (1 - (downsampled.nbytes / original.nbytes)) * 100

    print(f"\n--- DOWNSAMPLING ANALYSIS (N = {N}) ---")
    print(f"Original Shape : {original.shape} | Memory: {original.nbytes:,} bytes")
    print(f"Downsampled Shape : {downsampled.shape} | Memory: {downsampled.nbytes:,} bytes")
    print(f"Re-expanded Shape : {re_expanded.shape} | Visual: Blocky Pixelation")
    print(f"Dimension Reduction: {dim_reduction_pct:.2f}% reduction per axis")
    print(f"Memory Savings : {memory_reduction_pct:.2f}% data reduction")

    # Visual comparison
    fig, axes = plt.subplots(1, 2, figsize=(14, 6))
    axes[0].imshow(original)
    axes[0].set_title("Original")
    axes[0].axis("off")

    axes[1].imshow(re_expanded)
    axes[1].set_title(f"Re-expanded after N={N} Striding (Pixelated)")
    axes[1].axis("off")

    plt.tight_layout()
    plt.savefig("task4_pixelation.png", dpi=150)
    plt.show()


if __name__ == "__main__":
    main()
