"""
Generates an original synthetic 'sample.jpg' (1920x1080, RGB) for use in
Task 3 (channel extraction) and Task 4 (downsampling).
This is procedurally generated artwork -- not a copyrighted photo.
"""

import numpy as np
from PIL import Image, ImageDraw

W, H = 1920, 1080
img = Image.new("RGB", (W, H))
draw = ImageDraw.Draw(img)

# Sky gradient (blue -> pale orange near horizon)
for y in range(H):
    t = y / H
    r = int(60 + t * 180)
    g = int(110 + t * 110)
    b = int(200 - t * 90)
    draw.line([(0, y), (W, y)], fill=(r, g, b))

# Sun
draw.ellipse([1500, 120, 1680, 300], fill=(255, 221, 128))

# Mountains (layered triangles)
draw.polygon([(0, 650), (400, 380), (800, 650)], fill=(90, 100, 140))
draw.polygon([(500, 680), (950, 420), (1400, 680)], fill=(70, 80, 120))
draw.polygon([(1100, 700), (1550, 460), (1920, 700)], fill=(55, 65, 100))

# Ground
draw.rectangle([0, 700, W, H], fill=(60, 140, 70))

# A few trees
for x in [150, 300, 1650, 1800]:
    draw.rectangle([x, 780, x + 20, 860], fill=(90, 60, 40))
    draw.ellipse([x - 40, 700, x + 60, 800], fill=(40, 110, 50))

arr = np.array(img, dtype=np.uint8)
print("sample.jpg array shape:", arr.shape)
img.save("sample.jpg", quality=95)
