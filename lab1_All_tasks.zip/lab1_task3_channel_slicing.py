"""
LAB 1 - Task 3: Channel Slicing & Isolation
HCI & Computer Graphics
"""

import numpy as np
import matplotlib.pyplot as plt
from PIL import Image


def main():
    # 1. Load input image into a NumPy array
    img = np.array(Image.open("sample.jpg").convert("RGB"))

    # 2. Extract 2D intensity grids for R, G, B via Axis 2 slicing
    red_channel = img[:, :, 0]
    green_channel = img[:, :, 1]
    blue_channel = img[:, :, 2]

    # 3. Construct 3D color arrays with only one channel active
    red_only = np.zeros_like(img)
    red_only[:, :, 0] = red_channel

    green_only = np.zeros_like(img)
    green_only[:, :, 1] = green_channel

    blue_only = np.zeros_like(img)
    blue_only[:, :, 2] = blue_channel

    print("\n--- CHANNEL EXTRACTION SUMMARY ---")
    print(f"Original Image Shape : {img.shape}")
    print(f"Red Channel 2D Shape : {red_channel.shape} | Mean Intensity: {red_channel.mean():.2f}")
    print(f"Green Channel 2D Shape: {green_channel.shape} | Mean Intensity: {green_channel.mean():.2f}")
    print(f"Blue Channel 2D Shape : {blue_channel.shape} | Mean Intensity: {blue_channel.mean():.2f}")
    print("Display Window : Matplotlib 2x3 Subplot Grid Rendered.")

    # 4. Display in a 2x3 subplot layout
    fig, axes = plt.subplots(2, 3, figsize=(15, 8))

    axes[0, 0].imshow(red_only)
    axes[0, 0].set_title("Red-Only")
    axes[0, 0].axis("off")

    axes[0, 1].imshow(green_only)
    axes[0, 1].set_title("Green-Only")
    axes[0, 1].axis("off")

    axes[0, 2].imshow(blue_only)
    axes[0, 2].set_title("Blue-Only")
    axes[0, 2].axis("off")

    axes[1, 0].imshow(red_channel, cmap="gray")
    axes[1, 0].set_title("Red Channel (Grayscale)")
    axes[1, 0].axis("off")

    axes[1, 1].imshow(green_channel, cmap="gray")
    axes[1, 1].set_title("Green Channel (Grayscale)")
    axes[1, 1].axis("off")

    axes[1, 2].imshow(blue_channel, cmap="gray")
    axes[1, 2].set_title("Blue Channel (Grayscale)")
    axes[1, 2].axis("off")

    plt.tight_layout()
    plt.savefig("task3_channel_grid.png", dpi=150)
    plt.show()


if __name__ == "__main__":
    main()
