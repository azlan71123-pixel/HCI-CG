"""
LAB 1 - Task 2: Environment Setup & Synthetic Image Matrix Creation
HCI & Computer Graphics
"""

import numpy as np


def main():
    # 300 (H) x 400 (W) x 3 (C) image array initialized with zeros
    img = np.zeros((300, 400, 3), dtype=np.uint8)

    h, w, c = img.shape
    mid_h, mid_w = h // 2, w // 2

    # Top-Left Quadrant: Pure Red
    img[0:mid_h, 0:mid_w] = [255, 0, 0]

    # Top-Right Quadrant: Pure Green
    img[0:mid_h, mid_w:w] = [0, 255, 0]

    # Bottom-Left Quadrant: Pure Blue
    img[mid_h:h, 0:mid_w] = [0, 0, 255]

    # Bottom-Right Quadrant: White
    img[mid_h:h, mid_w:w] = [255, 255, 255]

    print("\n--- SYNTHETIC MATRIX METRICS ---")
    print(f"Array Shape (H, W, C) : {img.shape}")
    print(f"Data Type : {img.dtype}")
    print(f"Total Elements : {img.size:,} values")
    print(f"Memory Footprint : {img.nbytes:,} bytes ({img.nbytes / 1024:.2f} KB)")

    return img


if __name__ == "__main__":
    main()
