"""
LAB 1 - Task 1: Display Pixel Density (PPI/DPI) Calculator
HCI & Computer Graphics
"""

import math


def classify_density(dpi):
    if dpi < 100:
        return "Low Density (Standard Monitor)"
    elif 100 <= dpi <= 200:
        return "Medium Density (HD Display)"
    else:
        return "High Density (Retina / Mobile)"


def main():
    w_px = int(input("Enter horizontal resolution (pixels): "))
    h_px = int(input("Enter vertical resolution (pixels): "))
    d_inches = float(input("Enter physical diagonal size (inches): "))

    total_pixels = w_px * h_px

    gcd = math.gcd(w_px, h_px)
    ratio_w = w_px // gcd
    ratio_h = h_px // gcd

    diagonal_px = math.sqrt(w_px ** 2 + h_px ** 2)
    dpi = diagonal_px / d_inches

    category = classify_density(dpi)

    print("\n--- DISPLAY METRICS ANALYSIS ---")
    print(f"Total Pixel Count : {total_pixels:,} pixels")
    print(f"Aspect Ratio : {ratio_w}:{ratio_h}")
    print(f"Calculated DPI : {dpi:.2f} DPI")
    print(f"Density Category : {category}")


if __name__ == "__main__":
    main()
